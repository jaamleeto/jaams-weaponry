
package net.jaams.weaponry.entity;

import net.minecraftforge.network.PlayMessages;

import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ItemParticleOption;

import net.jaams.weaponry.util.ModProjectiles;
import net.jaams.weaponry.init.ModItems;
import net.jaams.weaponry.init.ModEntities;
import net.jaams.weaponry.configuration.common.TraitsConfig;
import net.jaams.weaponry.configuration.common.ProjectileCommonConfig;
import net.jaams.weaponry.component.projectile.BaseWeaponProjectileEntity;

public class ShurikenProjectileEntity extends BaseWeaponProjectileEntity {
	public ShurikenProjectileEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(ModEntities.SHURIKEN_PROJECTILE.get(), world);
	}

	public ShurikenProjectileEntity(EntityType<? extends ShurikenProjectileEntity> type, Level world) {
		super(type, world);
	}

	public ShurikenProjectileEntity(EntityType<? extends ShurikenProjectileEntity> type, double x, double y, double z, Level world) {
		super(type, x, y, z, world);
	}

	public ShurikenProjectileEntity(EntityType<? extends ShurikenProjectileEntity> type, LivingEntity entity, Level world) {
		super(type, entity, world);
	}

	public ShurikenProjectileEntity(Level world, LivingEntity entity, ItemStack weaponItem) {
		super(ModEntities.SHURIKEN_PROJECTILE.get(), entity, world, weaponItem);
		initializeProjectileStats(weaponItem);
	}

	@Override
	protected void onHitEntity(EntityHitResult result) {
		Entity target = result.getEntity();
		if (target instanceof LivingEntity livingTarget) {
			tryDisableUsingItem(livingTarget);
		}
		super.onHitEntity(result);
	}

	@Override
	protected float getDefaultBaseDamage(ItemStack weapon) {
		return ModProjectiles.getBaseDamage(weapon, ProjectileCommonConfig.SHURIKEN_PROJECTILE_BASE_DAMAGE.get());
	}

	@Override
	protected float getDefaultBaseKnockback(ItemStack weapon) {
		return ModProjectiles.getBaseKnockback(weapon, ProjectileCommonConfig.SHURIKEN_PROJECTILE_BASE_KNOCKBACK.get());
	}

	@Override
	protected int getDefaultPierceLevel(ItemStack weapon) {
		return ModProjectiles.getPiercingLevel(weapon, ProjectileCommonConfig.SHURIKEN_PROJECTILE_PIERCING_LEVEL.get());
	}

	@Override
	public ItemStack getDefaultWeaponItem() {
		return new ItemStack(ModItems.SHURIKEN.get());
	}

	@Override
	public EntityDimensions getDimensions(Pose pose) {
		return ModProjectiles.getDimensions(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_HITBOX_WIDTH.get().floatValue(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_HITBOX_HEIGHT.get().floatValue());
	}

	@Override
	protected SoundEvent getHitSound() {
		return ModProjectiles.getCustomProjectileSound(this.getWeaponItem(), "ProjectileHitSound", "projectile_hit", "shuriken_hit", SoundEvents.TRIDENT_HIT, projectileEntry -> projectileEntry.hit_sound);
	}

	@Override
	protected SoundEvent getGroundSound() {
		return ModProjectiles.getCustomProjectileSound(this.getWeaponItem(), "ProjectileGroundSound", "projectile_ground", "shuriken_ground", SoundEvents.TRIDENT_HIT_GROUND, projectileEntry -> projectileEntry.ground_sound);
	}

	@Override
	protected SoundEvent getLoyaltySound() {
		return ModProjectiles.getCustomProjectileSound(this.getWeaponItem(), "ProjectileReturnSound", "projectile_return", "shuriken_return", SoundEvents.TRIDENT_RETURN, projectileEntry -> projectileEntry.loyalty_sound);
	}

	@Override
	protected boolean shouldBreakOnEntityHit() {
		return ModProjectiles.shouldBreakOnEntityHit(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_BREAK_ON_ENTITY_HIT.get());
	}

	@Override
	protected boolean shouldBreakOnBlockHit() {
		return ModProjectiles.shouldBreakOnBlockHit(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_BREAK_ON_BLOCK_HIT.get());
	}

	@Override
	protected boolean shouldBreakOnPiercingExhausted() {
		return ModProjectiles.shouldBreakOnPiercingExhausted(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_BREAK_ON_PIERCING_EXHAUSTED.get());
	}

	@Override
	protected boolean shouldBreakAfterMaxBlockBreaks() {
		return ModProjectiles.shouldBreakAfterMaxBlockBreaks(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_BREAK_AFTER_MAX_BLOCK_BREAKS.get());
	}

	@Override
	public int getMaxBlockBreaks() {
		return ModProjectiles.getMaxBlockBreaks(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_MAX_BLOCK_BREAKS.get());
	}

	@Override
	public boolean canDisableShield(ItemStack shield, LivingEntity shieldHolder, Entity owner) {
		return ModProjectiles.canDisableShield(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_DISABLE_SHIELD.get());
	}

	@Override
	public int getShieldDisableCooldownTicks() {
		return ModProjectiles.getShieldDisableCooldownTicks(this.getWeaponItem(), 100);
	}

	@Override
	protected boolean isCustomBreakableBlock(BlockState state) {
		return ModProjectiles.isCustomBreakableBlock(this.getWeaponItem(), state, new ResourceLocation("minecraft:pointed_dripstone"));
	}

	@Override
	protected float getWaterInertia() {
		return ModProjectiles.getWaterInertia(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_WATER_INERTIA.get());
	}

	@Override
	public boolean isCritical() {
		if (!ModProjectiles.getAllowCriticals(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_ALLOW_CRITICALS.get())) {
			return false;
		}
		return super.isCritical();
	}

	@Override
	public int getIgnoreHitTicks() {
		return ModProjectiles.getIgnoreHitTicks(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_IGNORE_TICKS.get());
	}

	@Override
	protected void tickDespawn() {
		life++;
		int despawnTime = ModProjectiles.getDespawnTicks(this.getWeaponItem(), ProjectileCommonConfig.SHURIKEN_PROJECTILE_DESPAWN_TIME.get());
		if (life >= despawnTime) {
			if (ProjectileCommonConfig.SHURIKEN_PROJECTILE_DESPAWN_AS_ITEM.get() && this.pickup != AbstractArrow.Pickup.CREATIVE_ONLY) {
				ModProjectiles.dropAsItem(this.level(), this.getPickupItem().copy(), this.getX(), this.getY(), this.getZ());
			} else if (!this.level().isClientSide) {
				ItemStack itemStack = this.weaponItem.copy();
				if (!itemStack.isEmpty()) {
					((ServerLevel) this.level()).sendParticles(new ItemParticleOption(ParticleTypes.ITEM, itemStack), getX(), getY() + 0.5, getZ(), 5, 0.1d, 0.1d, 0.1d, 0.05d);
				}
			}
			discard();
		}
	}

	protected boolean isDisablingShotEnabled(ItemStack weapon) {
		return ModProjectiles.getDisablingShotEnabled(weapon, TraitsConfig.DISABLING_SHOT.get());
	}

	protected float getDisableChance(ItemStack weapon) {
		return ModProjectiles.getDisablingShotChance(weapon, TraitsConfig.DISABLING_SHOT_SHURIKEN_PROJECTILE_CHANCE.get().floatValue());
	}

	protected int getDisableCooldownTicks(ItemStack weapon) {
		return ModProjectiles.getDisablingShotCooldown(weapon, TraitsConfig.DISABLING_SHOT_SHURIKEN_PROJECTILE_COOLDOWN.get());
	}

	private void tryDisableUsingItem(LivingEntity target) {
		ItemStack weapon = this.getWeaponItem();
		if (this.level().isClientSide || !isDisablingShotEnabled(weapon)) {
			return;
		}
		if (target.isUsingItem()) {
			float chance = Math.max(0.0F, Math.min(1.0F, getDisableChance(weapon)));
			if (this.level().random.nextFloat() < chance) {
				if (target instanceof Player player) {
					ItemStack activeItem = player.getUseItem();
					if (!activeItem.isEmpty()) {
						int cooldown = getDisableCooldownTicks(weapon);
						if (cooldown > 0 && !player.getCooldowns().isOnCooldown(activeItem.getItem())) {
							player.getCooldowns().addCooldown(activeItem.getItem(), cooldown);
						}
					}
					player.stopUsingItem();
				} else {
					target.stopUsingItem();
				}
			}
		}
	}
}
